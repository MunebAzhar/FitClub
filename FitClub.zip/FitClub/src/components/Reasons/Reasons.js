import React from "react";
import "./Reasons.css";
import image1 from "../../assets/image1.png";
import image2 from "../../assets/image2.png";
import image3 from "../../assets/image3.png";
import image4 from "../../assets/image4.png";
import nb from "../../assets/nb.png";
import adidas from "../../assets/adidas.png";
import nike from "../../assets/nike.png";
import tick from "../../assets/tick.png";
export default function Reasons() {
  return (
    <div className="Reasons" id="reasons">
      {/* left-side */}
      <div className="left-r">
        <img src={image1} alt="" />
        <img src={image2} alt="" />
        <img src={image3} alt="" />
        <img src={image4} alt="" />
      </div>

      {/* right-side */}

      <div className="right-r">
        <div className="Reason-text">
          <span>Some reasons</span>
          <div>
            <span className="stroke-text">why </span>
            <span>Choose us ?</span>
          </div>
        </div>

        <div className="details-r">
          <div>
            <img src={tick} alt=""></img>
            <span>over 140+ expert coaches</span>
          </div>
          <div>
            <img src={tick} alt="" />
            <span>train smarter and faster then before</span>
          </div>
          <div>
            <img src={tick} alt="" />
            <span>1 free progra for new member</span>
          </div>
          <div>
            <img src={tick} alt="" />
            <span>reliable partners</span>
          </div>
        </div>
        <div className="partners">
        <span>Our partners</span>
        <div>
        <img src={nb} alt="" />
        <img src={adidas} alt="" />
        <img src={nike} alt="" />
        </div>
        </div>
      </div>
    </div>
  );
}
